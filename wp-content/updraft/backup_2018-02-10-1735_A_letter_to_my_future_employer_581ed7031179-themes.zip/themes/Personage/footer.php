<?php get_template_part( 'templates/footer' ); ?>

<!--end of main element-->
</div>
	<!-- Theme Hook -->
	<?php wp_footer(); ?>
</body>
</html>