<div class="head">
    <h4 class="date"><?php the_date("Y / j F"); ?></h4>
    <h1 class="title"><?php the_title(); ?></h1>
</div>